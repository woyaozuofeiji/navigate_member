<!-- Google tag (gtag.js) -->
<script async src="https://www.googletagmanager.com/gtag/js?id=G-TY92Y54C1Y"></script>
<script>
  window.dataLayer = window.dataLayer || [];
  function gtag(){dataLayer.push(arguments);}
  gtag('js', new Date());

  gtag('config', 'G-TY92Y54C1Y');
</script>

<!--<script charset="UTF-8" id="LA_COLLECT" src="//sdk.51.la/js-sdk-pro.min.js"></script>-->
<!--<script>LA.init({id:"K0lPXXc86JPqbnyn",ck:"K0lPXXc86JPqbnyn"})</script>-->